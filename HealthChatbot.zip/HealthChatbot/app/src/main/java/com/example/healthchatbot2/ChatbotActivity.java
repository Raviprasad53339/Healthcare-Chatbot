package com.example.healthchatbot2;



import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthchatbot2.model.ChatMessage;

import okhttp3.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ChatbotActivity extends AppCompatActivity {
    private static final String TAG = "HealthChatBot";
    private static final String API_KEY = "AIzaSyAxUsyE5C454jPbjjWzf1IEten1JwSbSAo"; // Replace with your API key
    private static final String API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key=" + API_KEY;

    private EditText userInput;
    private Button sendButton;
    private RecyclerView chatRecyclerView;
    private ChatAdapter chatAdapter;
    private List<ChatMessage> chatMessages;
    private final OkHttpClient client = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatbot);

        userInput = findViewById(R.id.userInput);
        sendButton = findViewById(R.id.sendButton);
        chatRecyclerView = findViewById(R.id.chatRecyclerView);

        chatMessages = new ArrayList<>();
        chatAdapter = new ChatAdapter(chatMessages);
        chatRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        chatRecyclerView.setAdapter(chatAdapter);

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userQuery = userInput.getText().toString().trim();
                if (!userQuery.isEmpty()) {
                    addMessage(userQuery, true);
                    getGeminiResponse(userQuery);
                    userInput.setText("");
                }
            }
        });
    }

    private void getGeminiResponse(String query) {
        try {
            JSONObject jsonBody = new JSONObject();
            JSONArray contentsArray = new JSONArray();
            JSONObject userMessage = new JSONObject();

            JSONArray partsArray = new JSONArray();
            JSONObject textObject = new JSONObject();
            textObject.put("text", query);
            partsArray.put(textObject);

            userMessage.put("role", "user");
            userMessage.put("parts", partsArray);
            contentsArray.put(userMessage);

            jsonBody.put("contents", contentsArray);

            RequestBody body = RequestBody.create(MediaType.get("application/json; charset=utf-8"), jsonBody.toString());
            Request request = new Request.Builder()
                    .url(API_URL)
                    .post(body)
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "API Request Failed: " + e.getMessage());
                    runOnUiThread(() -> addMessage("Error: " + e.getMessage(), false));
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (!response.isSuccessful()) {
                        String errorResponse = response.body().string();
                        Log.e(TAG, "API Response Failed: " + response.code() + " - " + errorResponse);
                        runOnUiThread(() -> addMessage("API Error: " + response.code(), false));
                        return;
                    }

                    try {
                        String responseData = response.body().string();
                        Log.d(TAG, "API Response: " + responseData);

                        JSONObject jsonResponse = new JSONObject(responseData);
                        JSONArray candidates = jsonResponse.optJSONArray("candidates");

                        if (candidates != null && candidates.length() > 0) {
                            JSONObject content = candidates.getJSONObject(0).optJSONObject("content");
                            if (content != null) {
                                JSONArray parts = content.optJSONArray("parts");
                                if (parts != null && parts.length() > 0) {
                                    String botReply = parts.getJSONObject(0).optString("text", "No response from AI");
                                    runOnUiThread(() -> addMessage(botReply, false));
                                } else {
                                    runOnUiThread(() -> addMessage("No valid response from API", false));
                                }
                            } else {
                                runOnUiThread(() -> addMessage("No valid response from API", false));
                            }
                        } else {
                            runOnUiThread(() -> addMessage("No valid response from API", false));
                        }

                    } catch (Exception e) {
                        Log.e(TAG, "Parsing error: " + e.getMessage());
                        runOnUiThread(() -> addMessage("Parsing error: " + e.getMessage(), false));
                    }
                }
            });

        } catch (Exception e) {
            Log.e(TAG, "JSON Exception: " + e.getMessage());
            runOnUiThread(() -> addMessage("JSON Error: " + e.getMessage(), false));
        }
    }

    private void addMessage(String text, boolean isUser) {
        chatMessages.add(new ChatMessage(text, isUser));
        chatAdapter.notifyItemInserted(chatMessages.size() - 1);
        chatRecyclerView.smoothScrollToPosition(chatMessages.size() - 1);
    }
}
